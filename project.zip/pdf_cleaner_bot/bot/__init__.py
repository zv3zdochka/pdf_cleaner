"""Telegram bot layer (aiogram).

Keep Telegram-specific glue here (handlers, dispatcher wiring).
"""
